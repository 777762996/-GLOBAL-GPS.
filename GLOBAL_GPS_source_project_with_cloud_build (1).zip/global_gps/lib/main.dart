import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';

void main() => runApp(const GlobalGpsApp());

class GlobalGpsApp extends StatelessWidget {
  const GlobalGpsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GLOBAL GPS',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF087E8B)),
        useMaterial3: true,
      ),
      home: const GpsHomePage(),
    );
  }
}

class GpsHomePage extends StatefulWidget {
  const GpsHomePage({super.key});

  @override
  State<GpsHomePage> createState() => _GpsHomePageState();
}

class _GpsHomePageState extends State<GpsHomePage> {
  final MapController _mapController = MapController();
  Position? _position;
  String _status = 'اضغط على تحديد موقعي للبدء';
  bool _loading = false;

  Future<void> _locateMe() async {
    setState(() {
      _loading = true;
      _status = 'جارٍ التحقق من صلاحية الموقع...';
    });

    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        setState(() => _status = 'فعّل خدمة الموقع GPS من إعدادات الهاتف.');
        return;
      }

      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied) {
        setState(() => _status = 'لم يتم منح إذن الموقع.');
        return;
      }
      if (permission == LocationPermission.deniedForever) {
        setState(() => _status = 'إذن الموقع مرفوض نهائياً. افتح إعدادات التطبيق واسمح بالموقع.');
        return;
      }

      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 25),
        ),
      );

      if (!mounted) return;
      setState(() {
        _position = position;
        _status = 'تم تحديد موقعك بنجاح';
      });
      _mapController.move(
        LatLng(position.latitude, position.longitude),
        15,
      );
    } catch (e) {
      if (mounted) {
        setState(() => _status = 'تعذر تحديد الموقع. تحقق من GPS ثم حاول مجدداً.');
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final point = _position == null
        ? null
        : LatLng(_position!.latitude, _position!.longitude);

    return Scaffold(
      appBar: AppBar(
        title: const Text('GLOBAL GPS'),
        centerTitle: true,
        actions: [
          IconButton(
            tooltip: 'حول التطبيق',
            onPressed: () => showAboutDialog(
              context: context,
              applicationName: 'GLOBAL GPS',
              applicationVersion: '1.0.0',
              children: const [
                Text('تطبيق لتحديد موقع هذا الهاتف. مشاركة الموقع مع الآخرين غير مفعلة في هذه النسخة.'),
              ],
            ),
            icon: const Icon(Icons.info_outline),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: FlutterMap(
              mapController: _mapController,
              options: MapOptions(
                initialCenter: const LatLng(24.0, 45.0),
                initialZoom: 4,
              ),
              children: [
                TileLayer(
                  urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                  userAgentPackageName: 'com.example.global_gps',
                ),
                if (point != null)
                  MarkerLayer(
                    markers: [
                      Marker(
                        point: point,
                        width: 52,
                        height: 52,
                        child: const Icon(
                          Icons.my_location,
                          color: Color(0xFFD62828),
                          size: 38,
                        ),
                      ),
                    ],
                  ),
                RichAttributionWidget(
                  attributions: [
                    TextSourceAttribution(
                      'OpenStreetMap contributors',
                      onTap: () {},
                    ),
                  ],
                ),
              ],
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    _status,
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  if (_position != null) ...[
                    const SizedBox(height: 10),
                    _InfoLine(label: 'خط العرض', value: _position!.latitude.toStringAsFixed(6)),
                    _InfoLine(label: 'خط الطول', value: _position!.longitude.toStringAsFixed(6)),
                    _InfoLine(
                      label: 'الدقة التقريبية',
                      value: '${_position!.accuracy.toStringAsFixed(1)} متر',
                    ),
                    _InfoLine(
                      label: 'السرعة',
                      value: '${(_position!.speed * 3.6).clamp(0, 999).toStringAsFixed(1)} كم/س',
                    ),
                  ],
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: _loading ? null : _locateMe,
                    icon: _loading
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.my_location),
                    label: Text(_loading ? 'جارٍ تحديد الموقع...' : 'تحديد موقعي'),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'الخصوصية: موقعك يبقى على هذا الهاتف في هذه النسخة ولا يُرسل إلى خادم أو مستخدم آخر.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12, color: Colors.black54),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoLine extends StatelessWidget {
  const _InfoLine({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: const TextStyle(color: Colors.black54)),
            Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
          ],
        ),
      );
}
